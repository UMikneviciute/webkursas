/*
1. Sugeneruokite masyvą iš 30 elementų (indeksai nuo 0 iki 29), kurių reikšmės yra atsitiktiniai skaičiai nuo 5 iki 25.
*/



/*
2. Naudodamiesi 1 uždavinio masyvu:
- Suskaičiuokite kiek masyve yra reikšmių didesnių už 10;
- Raskite didžiausią masyvo reikšmę;
- Suskaičiuokite visų reikšmių sumą;
- Sukurkite naują masyvą, kurio reikšmės yra 1 uždavinio masyvo reikšmes minus tos reikšmės indeksas;
- Papildykite masyvą papildomais 10 elementų su reikšmėmis nuo 5 iki 25, kad bendras masyvas padidėtų iki indekso 39;
- Iš masyvo elementų sukurkite du naujus masyvus. Vienas turi būti sudarytas iš neporinių indekso reikšmių, o kitas iš porinių;
- Masyvo elementus su poriniais indeksais padarykite lygius 0 jeigu jie didesni už 15;
- Suraskite pirmą (mažiausią) indeksą, kurio elemento reikšmė didesnė už 10;
*/



/*
3. Sugeneruokite masyvą, kurio reikšmės atsitiktinės raidės A, B, C ir D, o ilgis 200. Suskaičiuokite kiek yra kiekvienos raidės.
*/



/*
4. Išrūšiuokite 3 uždavinio masyvą pagal abecėlę.
*/



/*
5. Sugeneruokite masyvą, kurio reikšmės yra atsitiktiniai skaičiai nuo 100 iki 999. Masyvo ilgis 100. Masyvo reikšmės turi būti unikalios (t.y. neturi kartotis).
*/

